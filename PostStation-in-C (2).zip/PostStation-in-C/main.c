#include<stdio.h>
#include<stdlib.h>
#include"common.h"



int main()
{
    char time[50];
    getTime(time);
    printf("��ǰʱ�䣺%s", time);
    constructor();
    while(1)
    {
        default_menu();
        int choice = 0;
        

        choice = getValidInt(1,3);
        switch (choice) {
        case 1:
            cur_user = login();
            if(!cur_user)break;
            if (cur_user->privilege == 0) {
                while(cur_user){
                    admin_menu();
                }
            }
            else if (cur_user->privilege == 1) {
                while(cur_user){
                    user_menu(); 
                }
            }
            else if (cur_user->privilege == 2) {
                while(cur_user){
                    postman_menu();
                } 
            }
            break;
        case 2:
            regist(); 
            save_users();
            break;
        case 3:
            destructor();//make sure to call this before exit
            exit(0);
        default:
            printf("��Ч���������������룡\n");
        }
        

    }
}
