PostStation System
Author: zjr lyd lyl xyh 
Date: 2025-3-9
Version: 1.0
Description: A system for post station.
Compile command: gcc main.c menu.c user.c file.c package.c -std=c99 -o main        